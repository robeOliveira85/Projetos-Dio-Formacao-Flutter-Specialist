enum TipoNotificacao { SMS, PUSH_NOTIFICATION, EMAIL, NENHUM }
