import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:trilhaapp/my_app.dart';

void main() {
  runApp(const MyApp());
}



