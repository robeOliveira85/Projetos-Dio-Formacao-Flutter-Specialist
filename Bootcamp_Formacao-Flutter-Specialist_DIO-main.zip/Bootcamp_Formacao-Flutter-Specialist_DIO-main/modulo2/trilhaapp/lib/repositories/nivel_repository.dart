class NivelRepository {
  List<String> retornaNiveis() {
    return ["Iniciante", "Intermediário", "Avançado"];
  }
}
