class LinguagensRepository {
  List<String> retornaLinguagens() {
    return ["Dart", "C#", "Pyton", "Java"];
  }
}
