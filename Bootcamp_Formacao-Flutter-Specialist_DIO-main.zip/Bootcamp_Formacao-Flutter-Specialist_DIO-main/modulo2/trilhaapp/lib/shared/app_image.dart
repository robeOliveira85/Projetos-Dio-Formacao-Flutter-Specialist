class AppImage {
  /*O get serve para que tenha uma variavel que não tenha set ou seja ninguem pode alterar*/
  static String get img1 => "lib/images/img1.jpg";
  static String get img2 => "lib/images/img2.jpg";
  static String get img3 => "lib/images/img3.jpg";
}
