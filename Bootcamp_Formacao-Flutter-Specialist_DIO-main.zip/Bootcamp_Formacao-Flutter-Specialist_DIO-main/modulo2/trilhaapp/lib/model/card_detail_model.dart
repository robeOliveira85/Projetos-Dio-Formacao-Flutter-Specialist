class CardDetailModel {
  int id;
  String title;
  String url;
  String text;
  CardDetailModel({
    required this.id,
    required this.title,
    required this.url,
    required this.text,
  });
}
