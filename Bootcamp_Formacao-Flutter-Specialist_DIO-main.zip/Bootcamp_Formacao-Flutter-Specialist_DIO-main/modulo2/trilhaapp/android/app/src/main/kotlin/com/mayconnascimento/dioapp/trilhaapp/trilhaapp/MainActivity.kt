package com.mayconnascimento.dioapp.trilhaapp.trilhaapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
